rootProject.name = "LumqeraCore"
