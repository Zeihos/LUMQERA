package ru.lumqera.core;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.util.*;
import java.util.logging.Logger;

/** Tracks PvP counters and retains cooldown pairs across restarts. */
final class StatsService {
    private final File file;
    private final Logger logger;
    private final CombatRegistry registry = new CombatRegistry();
    private final long farmCooldownMs;

    StatsService(File folder, Logger logger, long farmCooldownMs) {
        file = new File(folder, "pvp.yml"); this.logger = logger;
        this.farmCooldownMs = Math.max(0, farmCooldownMs);
    }
    CombatRegistry state() { return registry; }
    CombatRegistry.Stats of(UUID id) { return registry.get(id); }
    CombatRegistry.Result recordDeath(UUID victim, UUID killer, boolean allies) {
        CombatRegistry.Result result = registry.recordDeath(victim, killer, allies, System.currentTimeMillis(), farmCooldownMs);
        save(); return result;
    }
    void load() {
        if (!file.isFile()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection people = yaml.getConfigurationSection("players");
        if (people != null) for (String id : people.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(id);
                registry.restore(uuid, yaml.getInt("players." + id + ".kills"), yaml.getInt("players." + id + ".deaths"));
            } catch (IllegalArgumentException ignored) { logger.warning("Broken stats entry: " + id); }
        }
        ConfigurationSection pairs = yaml.getConfigurationSection("recent-pairs");
        if (pairs != null) for (String encoded : pairs.getKeys(false)) {
            try {
                String key = new String(Base64.getUrlDecoder().decode(encoded), java.nio.charset.StandardCharsets.UTF_8);
                registry.restoreRecentPair(key, yaml.getLong("recent-pairs." + encoded));
            } catch (IllegalArgumentException ignored) { logger.warning("Broken recent-pair entry"); }
        }
    }
    boolean save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (var entry : registry.all().entrySet()) {
            String prefix = "players." + entry.getKey();
            yaml.set(prefix + ".kills", entry.getValue().kills);
            yaml.set(prefix + ".deaths", entry.getValue().deaths);
        }
        for (var entry : registry.recentPairs(System.currentTimeMillis(), farmCooldownMs).entrySet()) {
            String key = Base64.getUrlEncoder().withoutPadding().encodeToString(entry.getKey().getBytes(java.nio.charset.StandardCharsets.UTF_8));
            yaml.set("recent-pairs." + key, entry.getValue());
        }
        return YamlStore.save(yaml, file.toPath(), logger);
    }
}
