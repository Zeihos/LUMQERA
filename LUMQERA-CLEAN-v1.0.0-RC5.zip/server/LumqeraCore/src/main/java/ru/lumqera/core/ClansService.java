package ru.lumqera.core;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.util.*;
import java.util.logging.Logger;

/** Persistence and invitations around the Bukkit-independent ClanRegistry. Main thread only. */
final class ClansService {
    record Invitation(String clanKey, long expiresAt) {}
    private final File file;
    private final Logger logger;
    private final ClanRegistry registry = new ClanRegistry();
    private final Map<UUID, Invitation> invitations = new HashMap<>();
    private final Map<UUID, Long> lastInvitedBy = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();

    ClansService(File dataFolder, Logger logger) { file = new File(dataFolder, "clans.yml"); this.logger = logger; }
    ClanRegistry state() { return registry; }
    Collection<ClanRegistry.Clan> all() { return registry.all(); }
    ClanRegistry.Clan of(UUID id) { return registry.of(id); }
    ClanRegistry.Clan byName(String name) { return registry.byName(name); }
    boolean sameClan(UUID a, UUID b) { return registry.sameClan(a, b); }
    boolean create(String name, UUID owner) { boolean ok = registry.create(name, owner); if (ok) save(); return ok; }
    boolean remove(ClanRegistry.Clan clan, UUID player) { boolean ok = registry.removeMember(clan, player); if (ok) save(); return ok; }
    boolean promote(ClanRegistry.Clan clan, UUID actor, UUID target) { boolean ok = registry.promote(clan, actor, target); if (ok) save(); return ok; }
    boolean demote(ClanRegistry.Clan clan, UUID actor, UUID target) { boolean ok = registry.demote(clan, actor, target); if (ok) save(); return ok; }
    boolean transfer(ClanRegistry.Clan clan, UUID actor, UUID target) { boolean ok = registry.transfer(clan, actor, target); if (ok) save(); return ok; }
    void reward(UUID player, int points) { registry.addInfluence(player, points); save(); }
    boolean rewardClan(String name, int points) {
        ClanRegistry.Clan clan=byName(name);
        if (clan==null || points<=0) return false;
        clan.influence=(int)Math.min(Integer.MAX_VALUE,(long)clan.influence+points);
        return save();
    }
    boolean disband(ClanRegistry.Clan clan) {
        if (!registry.disband(clan)) return false;
        invitations.entrySet().removeIf(e -> e.getValue().clanKey().equals(ClanRegistry.key(clan.name)));
        save(); return true;
    }
    void remember(UUID id, String name) {
        if (id == null || name == null || !name.matches("[A-Za-z0-9_]{3,16}")) return;
        if (!name.equals(names.put(id, name))) save();
    }
    String knownName(UUID id) { return names.getOrDefault(id, id.toString().substring(0, 8)); }
    UUID memberByName(ClanRegistry.Clan clan, String nickname) {
        if (clan == null || nickname == null) return null;
        for (UUID id : clan.members) if (knownName(id).equalsIgnoreCase(nickname)) return id;
        return null;
    }
    boolean invite(ClanRegistry.Clan clan, UUID actor, UUID target, long ttlMs, long cooldownMs, long now) {
        if (clan == null || !clan.isOfficerOrOwner(actor) || of(target) != null) return false;
        Long last = lastInvitedBy.get(actor);
        if (last != null && now >= last && now - last < cooldownMs) return false;
        lastInvitedBy.put(actor, now);
        invitations.put(target, new Invitation(ClanRegistry.key(clan.name), now + Math.max(1000L, ttlMs)));
        return true;
    }
    ClanRegistry.Clan accept(UUID player, int maxMembers, long now) {
        Invitation invitation = invitations.remove(player);
        if (invitation == null || invitation.expiresAt() < now) return null;
        ClanRegistry.Clan clan = byName(invitation.clanKey());
        if (clan == null || !registry.addMember(clan, player, maxMembers)) return null;
        save(); return clan;
    }
    void load() {
        if (!file.isFile()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection storedNames = yaml.getConfigurationSection("players");
        if (storedNames == null && yaml.contains("players")) throw new IllegalStateException("clans.yml has an invalid players section");
        if (storedNames != null) for (String id : storedNames.getKeys(false)) {
            try {
                String value = yaml.getString("players." + id);
                if (value == null || !value.matches("[A-Za-z0-9_]{3,16}"))
                    throw new IllegalStateException("Invalid saved player nickname for " + id);
                names.put(UUID.fromString(id), value);
            } catch (IllegalArgumentException ex) { throw new IllegalStateException("Invalid stored player name ID: " + id, ex); }
        }
        ConfigurationSection section = yaml.getConfigurationSection("clans");
        if (section == null) {
            if (yaml.contains("clans")) throw new IllegalStateException("clans.yml has an invalid clans section");
            return;
        }
        for (String name : section.getKeys(false)) {
            try {
                String prefix = "clans." + name;
                UUID owner = UUID.fromString(yaml.getString(prefix + ".owner", ""));
                List<UUID> members = parseUUIDs(yaml.getStringList(prefix + ".members"));
                List<UUID> officers = parseUUIDs(yaml.getStringList(prefix + ".officers"));
                int influence = yaml.getInt(prefix + ".influence", 0);
                if (!ClanRegistry.validName(name) || !members.contains(owner) ||
                    members.size() != new HashSet<>(members).size() ||
                    !members.containsAll(officers) || officers.contains(owner) || influence < 0 ||
                    members.stream().anyMatch(id -> registry.of(id) != null)) {
                    throw new IllegalStateException("Invalid clan membership or influence: " + name);
                }
                if (!registry.register(name, owner, members, officers, influence))
                    throw new IllegalStateException("Duplicate or invalid clan: " + name);
            } catch (IllegalArgumentException exception) {
                throw new IllegalStateException("Malformed stored clan: " + name, exception);
            }
        }
    }
    private List<UUID> parseUUIDs(List<String> strings) {
        List<UUID> result = new ArrayList<>();
        for (String input : strings) {
            try { result.add(UUID.fromString(input)); }
            catch (IllegalArgumentException ex) { throw new IllegalStateException("Invalid clan member UUID: " + input, ex); }
        }
        return result;
    }
    boolean save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (ClanRegistry.Clan clan : all()) {
            String prefix = "clans." + clan.name;
            yaml.set(prefix + ".owner", clan.owner.toString());
            yaml.set(prefix + ".members", clan.members.stream().map(UUID::toString).toList());
            yaml.set(prefix + ".officers", clan.officers.stream().map(UUID::toString).toList());
            yaml.set(prefix + ".influence", clan.influence);
        }
        for (var entry : names.entrySet()) yaml.set("players." + entry.getKey(), entry.getValue());
        return YamlStore.save(yaml, file.toPath(), logger);
    }
}
