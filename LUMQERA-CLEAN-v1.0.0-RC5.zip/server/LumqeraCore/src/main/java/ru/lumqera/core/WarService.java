package ru.lumqera.core;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.util.*;
import java.util.logging.Logger;

/** Disk snapshot for active wars and lifetime records; pending challenges intentionally do not persist. */
final class WarService {
    private final File file;
    private final Logger logger;
    private final WarRegistry state = new WarRegistry();
    WarService(File folder,Logger logger) { file=new File(folder,"wars.yml"); this.logger=logger; }
    WarRegistry state() { return state; }
    void load(ClansService clans) {
        if (!file.isFile()) return;
        YamlConfiguration yaml=YamlConfiguration.loadConfiguration(file);
        ConfigurationSection records=yaml.getConfigurationSection("records");
        if (records!=null) for (String name:records.getKeys(false)) if (clans.byName(name)!=null) {
            state.restoreRecord(name,yaml.getInt("records."+name+".wins"),
                    yaml.getInt("records."+name+".losses"),yaml.getInt("records."+name+".draws"));
        }
        ConfigurationSection wars=yaml.getConfigurationSection("active");
        if (wars!=null) for (String name:wars.getKeys(false)) {
            String path="active."+name;
            String a=yaml.getString(path+".a"),b=yaml.getString(path+".b");
            if (clans.byName(a)!=null&&clans.byName(b)!=null)
                state.restoreWar(a,b,yaml.getLong(path+".ends-at"),yaml.getInt(path+".goal"),
                        yaml.getInt(path+".a-score"),yaml.getInt(path+".b-score"));
            else logger.warning("Skipped war with missing clan: "+name);
        }
    }
    boolean save() {
        YamlConfiguration yaml=new YamlConfiguration();
        int i=0;
        for (WarRegistry.War w:state.active()) {
            String key="active."+(++i);
            yaml.set(key+".a",w.a); yaml.set(key+".b",w.b); yaml.set(key+".ends-at",w.endsAt);
            yaml.set(key+".goal",w.goal); yaml.set(key+".a-score",w.aScore); yaml.set(key+".b-score",w.bScore);
        }
        Set<String> recorded=new TreeSet<>();
        recorded.addAll(state.wins().keySet());
        recorded.addAll(state.losses().keySet());
        recorded.addAll(state.draws().keySet());
        for (String clan:recorded) {
            yaml.set("records."+clan+".wins",state.wins(clan));
            yaml.set("records."+clan+".losses",state.losses(clan));
            yaml.set("records."+clan+".draws",state.draws(clan));
        }
        return YamlStore.save(yaml,file.toPath(),logger);
    }
}
