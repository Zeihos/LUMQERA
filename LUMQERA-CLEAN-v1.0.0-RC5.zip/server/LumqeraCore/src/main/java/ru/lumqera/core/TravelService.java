package ru.lumqera.core;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;
import java.util.logging.Logger;

/** World-UUID based locations persist across restart without auto-loading missing worlds. */
final class TravelService {
    private final File file;
    private final Logger logger;
    private final TravelRegistry registry = new TravelRegistry();

    TravelService(File folder, Logger logger) { this.file = new File(folder, "travel.yml"); this.logger = logger; }
    TravelRegistry state() { return registry; }
    static TravelRegistry.Point point(Location loc) {
        return new TravelRegistry.Point(Objects.requireNonNull(loc.getWorld()).getUID(),
                loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
    }
    static Location centered(Location location) {
        return new Location(Objects.requireNonNull(location.getWorld()), location.getBlockX() + 0.5,
                location.getBlockY(), location.getBlockZ() + 0.5, location.getYaw(), location.getPitch());
    }
    Location location(TravelRegistry.Point point) {
        if (point == null) return null;
        World world = Bukkit.getWorld(point.world());
        return world == null ? null : new Location(world, point.x(), point.y(), point.z(), point.yaw(), point.pitch());
    }
    /** Must have solid ground and enough empty space for a standing player. */
    static boolean safe(Location dest) {
        if (dest == null || dest.getWorld() == null || !dest.getWorld().getWorldBorder().isInside(dest)) return false;
        int y = dest.getBlockY();
        if (y <= dest.getWorld().getMinHeight() || y + 1 >= dest.getWorld().getMaxHeight()) return false;
        return dest.getBlock().getType().isAir() && dest.clone().add(0, 1, 0).getBlock().getType().isAir()
                && dest.clone().add(0, -1, 0).getBlock().getType().isSolid();
    }
    void load() {
        if (!file.isFile()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        try { TravelRegistry.Point point = parse(yaml.getConfigurationSection("spawn")); if (point != null) registry.setSpawn(point); }
        catch (IllegalArgumentException e) { logger.warning("Invalid stored spawn: " + e.getMessage()); }
        ConfigurationSection homes = yaml.getConfigurationSection("homes");
        if (homes != null) for (String clan : homes.getKeys(false)) {
            if (!ClanRegistry.validName(clan)) { logger.warning("Skipped invalid home clan"); continue; }
            try {
                TravelRegistry.Point point = parse(homes.getConfigurationSection(clan));
                if (point != null) registry.setHome(clan, point);
            } catch (IllegalArgumentException e) { logger.warning("Skipped invalid home for " + clan); }
        }
    }
    private TravelRegistry.Point parse(ConfigurationSection section) {
        if (section == null) return null;
        return new TravelRegistry.Point(UUID.fromString(section.getString("world", "")),
                section.getDouble("x"), section.getDouble("y"), section.getDouble("z"),
                (float)section.getDouble("yaw"), (float)section.getDouble("pitch"));
    }
    private static void write(YamlConfiguration yaml, String prefix, TravelRegistry.Point point) {
        yaml.set(prefix + ".world", point.world().toString());
        yaml.set(prefix + ".x", point.x()); yaml.set(prefix + ".y", point.y()); yaml.set(prefix + ".z", point.z());
        yaml.set(prefix + ".yaw", point.yaw()); yaml.set(prefix + ".pitch", point.pitch());
    }
    boolean save() {
        YamlConfiguration yaml = new YamlConfiguration();
        if (registry.spawn() != null) write(yaml, "spawn", registry.spawn());
        registry.homes().forEach((clan, point) -> write(yaml, "homes." + clan, point));
        return YamlStore.save(yaml, file.toPath(), logger);
    }
    boolean validHome(String clan, LandService land) {
        return registry.validHome(clan, land.state());
    }
    void invalidateHomeIfUnclaimed(String clan, LandService land) {
        if (registry.home(clan) != null && !validHome(clan, land)) { registry.deleteHome(clan); save(); }
    }
}
