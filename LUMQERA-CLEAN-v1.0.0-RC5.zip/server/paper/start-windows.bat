@echo off
chcp 65001 >nul
title LUMQERA - Paper test server
cd /d "%~dp0"
if not exist paper.jar (
  echo [ERROR] Place official Paper 26.3 server as paper.jar in this folder.
  echo https://papermc.io/downloads/paper
  pause
  exit /b 1
)
java -version 2>&1
where java >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Java 25 not found.
  pause
  exit /b 1
)
for /f "tokens=3" %%V in ('java -version 2^>^&1 ^| findstr /i "version"') do set "JAVA_VERSION_RAW=%%~V"
for /f "tokens=1 delims=." %%V in ("%JAVA_VERSION_RAW%") do set "JAVA_MAJOR=%%V"
if not "%JAVA_MAJOR%"=="25" (
  echo [ERROR] Java 25 required. Found %JAVA_VERSION_RAW%.
  pause
  exit /b 1
)
java -Xms2G -Xmx4G -jar paper.jar --nogui
pause
