@echo off
chcp 65001 >nul
setlocal
title LUMQERA - Build Core Plugin
cd /d "%~dp0server\LumqeraCore"
where java >nul 2>nul
if errorlevel 1 (
 echo [ERROR] Java not found. Install JDK 25 and add it to PATH.
 pause
 exit /b 1
)
java -version 2>&1
where javac >nul 2>nul
if errorlevel 1 (
 echo [ERROR] JDK is required (javac not found).
 pause
 exit /b 1
)
for /f "tokens=3" %%V in ('java -version 2^>^&1 ^| findstr /i "version"') do set "JAVA_VERSION_RAW=%%~V"
for /f "tokens=1 delims=." %%V in ("%JAVA_VERSION_RAW%") do set "JAVA_MAJOR=%%V"
if not "%JAVA_MAJOR%"=="25" (
 echo [ERROR] JDK 25 required, found %JAVA_VERSION_RAW%.
 pause
 exit /b 1
)
where gradle >nul 2>nul
if errorlevel 1 (
 echo [ERROR] Gradle 9.x not found. Install Gradle 9 or use IntelliJ IDEA.
 pause
 exit /b 1
)
gradle build --no-daemon
if errorlevel 1 (
 echo [ERROR] Plugin compilation failed. Check Gradle output.
 pause
 exit /b 1
)
if not exist "build\libs\LumqeraCore-1.0.0-RC5.jar" (
 echo [ERROR] No expected JAR produced. Inspect build\libs.
 pause
 exit /b 1
)
echo [OK] Built: server\LumqeraCore\build\libs\LumqeraCore-1.0.0-RC5.jar
pause
